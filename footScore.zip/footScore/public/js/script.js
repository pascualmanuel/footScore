document.addEventListener(
  "DOMContentLoaded",
  () => {
    console.log("FootScore imported successfully!");
  },
  false
);
